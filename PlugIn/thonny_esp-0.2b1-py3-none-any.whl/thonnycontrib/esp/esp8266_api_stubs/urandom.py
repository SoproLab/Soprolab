def getrandbits():
    pass

def seed():
    pass

