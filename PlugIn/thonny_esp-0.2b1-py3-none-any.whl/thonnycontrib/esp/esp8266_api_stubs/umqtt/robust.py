
class MQTTClient:
    ''
    DEBUG = None
    DELAY = 2
    def _recv_len():
        pass

    def _send_str():
        pass

    def check_msg():
        pass

    def connect():
        pass

    def delay():
        pass

    def disconnect():
        pass

    def log():
        pass

    def ping():
        pass

    publish = None
    reconnect = None
    def set_callback():
        pass

    def set_last_will():
        pass

    def subscribe():
        pass

    wait_msg = None
simple = None
utime = None
