
class MQTTClient:
    ''
    def _recv_len():
        pass

    def _send_str():
        pass

    def check_msg():
        pass

    def connect():
        pass

    def disconnect():
        pass

    def ping():
        pass

    def publish():
        pass

    def set_callback():
        pass

    def set_last_will():
        pass

    def subscribe():
        pass

    def wait_msg():
        pass


class MQTTException:
    ''
def hexlify():
    pass

socket = None
struct = None
