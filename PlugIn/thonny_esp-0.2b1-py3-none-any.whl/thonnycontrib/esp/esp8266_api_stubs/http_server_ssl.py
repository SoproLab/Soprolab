CONTENT = None
def main():
    pass

socket = None
ssl = None
