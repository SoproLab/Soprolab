def acos():
    pass

def asin():
    pass

def atan():
    pass

def atan2():
    pass

def ceil():
    pass

def copysign():
    pass

def cos():
    pass

def degrees():
    pass

e = 2.71828
def exp():
    pass

def fabs():
    pass

def floor():
    pass

def fmod():
    pass

def frexp():
    pass

def isfinite():
    pass

def isinf():
    pass

def isnan():
    pass

def ldexp():
    pass

def log():
    pass

def modf():
    pass

pi = 3.14159
def pow():
    pass

def radians():
    pass

def sin():
    pass

def sqrt():
    pass

def tan():
    pass

def trunc():
    pass

