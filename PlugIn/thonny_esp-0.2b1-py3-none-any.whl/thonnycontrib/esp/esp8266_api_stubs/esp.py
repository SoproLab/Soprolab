SLEEP_LIGHT = 1
SLEEP_MODEM = 2
SLEEP_NONE = 0
def apa102_write():
    pass

def check_fw():
    pass

def deepsleep():
    pass

def dht_readinto():
    pass

def esf_free_bufs():
    pass

def flash_erase():
    pass

def flash_id():
    pass

def flash_read():
    pass

def flash_size():
    pass

def flash_user_start():
    pass

def flash_write():
    pass

def free():
    pass

def freemem():
    pass

def info():
    pass

def malloc():
    pass

def meminfo():
    pass

def neopixel_write():
    pass

def osdebug():
    pass

def set_native_code_location():
    pass

def sleep_type():
    pass

