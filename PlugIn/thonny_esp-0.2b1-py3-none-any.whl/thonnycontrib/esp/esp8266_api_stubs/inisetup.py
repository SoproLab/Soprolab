bdev = None
def check_bootsec():
    pass

def fs_corrupted():
    pass

network = None
def setup():
    pass

uos = None
def wifi():
    pass

