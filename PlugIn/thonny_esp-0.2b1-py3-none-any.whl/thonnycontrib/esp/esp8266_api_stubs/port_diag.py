esp = None
lwip = None
def main():
    pass

network = None
uctypes = None
