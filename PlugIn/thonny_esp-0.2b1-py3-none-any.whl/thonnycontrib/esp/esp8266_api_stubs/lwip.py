AF_INET = 2
AF_INET6 = 10
IPPROTO_IP = 0
IP_ADD_MEMBERSHIP = 1024
SOCK_DGRAM = 2
SOCK_RAW = 3
SOCK_STREAM = 1
SOL_SOCKET = 1
SO_REUSEADDR = 4
def callback():
    pass

def getaddrinfo():
    pass

def print_pcbs():
    pass

def reset():
    pass


class socket:
    ''
    def accept():
        pass

    def bind():
        pass

    def close():
        pass

    def connect():
        pass

    def listen():
        pass

    def makefile():
        pass

    def read():
        pass

    def readinto():
        pass

    def readline():
        pass

    def recv():
        pass

    def recvfrom():
        pass

    def send():
        pass

    def sendall():
        pass

    def sendto():
        pass

    def setblocking():
        pass

    def setsockopt():
        pass

    def settimeout():
        pass

    def write():
        pass

