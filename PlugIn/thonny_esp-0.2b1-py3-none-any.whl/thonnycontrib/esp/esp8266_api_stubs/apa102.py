
class APA102:
    ''
    ORDER = None
    def fill():
        pass

    def write():
        pass


class NeoPixel:
    ''
    ORDER = None
    def fill():
        pass

    def write():
        pass

def apa102_write():
    pass

