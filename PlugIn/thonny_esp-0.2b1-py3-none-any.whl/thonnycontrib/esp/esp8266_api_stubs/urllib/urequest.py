def urlopen():
    pass

usocket = None
