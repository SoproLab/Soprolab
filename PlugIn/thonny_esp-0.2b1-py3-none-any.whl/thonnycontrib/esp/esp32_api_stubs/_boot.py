bdev = None
gc = None
uos = None
