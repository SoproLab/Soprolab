
class ULP:
    ''
    RESERVE_MEM = 2040
    def load_binary():
        pass

    def run():
        pass

    def set_wakeup_period():
        pass

WAKEUP_ALL_LOW = None
WAKEUP_ANY_HIGH = None
def wake_on_ext0():
    pass

def wake_on_ext1():
    pass

def wake_on_touch():
    pass

