def a2b_base64():
    pass

def b2a_base64():
    pass

def crc32():
    pass

def hexlify():
    pass

def unhexlify():
    pass

