DEBUG = 0
binascii = None
def client_handshake():
    pass

hashlib = None
def server_handshake():
    pass

sys = None
