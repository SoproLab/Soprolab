CONFIG = './webrepl_cfg.py'
RC = './boot.py'
def change_daemon():
    pass

def exists():
    pass

def get_daemon_status():
    pass

def getpass():
    pass

def input_choice():
    pass

def input_pass():
    pass

machine = None
def main():
    pass

os = None
sys = None
