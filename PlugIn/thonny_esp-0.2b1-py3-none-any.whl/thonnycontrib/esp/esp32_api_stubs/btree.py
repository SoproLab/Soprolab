DESC = 2
INCL = 1
def open():
    pass

