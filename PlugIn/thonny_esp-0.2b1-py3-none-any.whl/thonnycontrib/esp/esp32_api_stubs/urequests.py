
class Response:
    ''
    def close():
        pass

    content = None
    def json():
        pass

    text = None
def delete():
    pass

def get():
    pass

def head():
    pass

def patch():
    pass

def post():
    pass

def put():
    pass

def request():
    pass

usocket = None
