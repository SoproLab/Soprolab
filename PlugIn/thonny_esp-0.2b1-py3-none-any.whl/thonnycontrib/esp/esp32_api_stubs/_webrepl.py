
class _webrepl:
    ''
    def close():
        pass

    def read():
        pass

    def readinto():
        pass

    def write():
        pass

def password():
    pass

