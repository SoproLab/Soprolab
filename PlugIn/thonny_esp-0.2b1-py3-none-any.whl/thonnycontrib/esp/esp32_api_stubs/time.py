def localtime():
    pass

def mktime():
    pass

def sleep():
    pass

def sleep_ms():
    pass

def sleep_us():
    pass

def ticks_add():
    pass

def ticks_cpu():
    pass

def ticks_diff():
    pass

def ticks_ms():
    pass

def ticks_us():
    pass

def time():
    pass

