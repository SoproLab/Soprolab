DIRTYPE = 'dir'

class FileSection:
    ''
    def read():
        pass

    def readinto():
        pass

    def skip():
        pass

REGTYPE = 'file'
TAR_HEADER = None

class TarFile:
    ''
    def extractfile():
        pass

    def next():
        pass


class TarInfo:
    ''
def roundup():
    pass

uctypes = None
